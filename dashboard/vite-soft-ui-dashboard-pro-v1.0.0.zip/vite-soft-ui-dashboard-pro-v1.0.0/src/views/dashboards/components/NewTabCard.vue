<template>
  <div class="border card h-100">
    <div
      class="text-center card-body d-flex flex-column justify-content-center"
    >
      <a href="javascript:;">
        <i
          class="mb-1 text-sm fa fa-plus text-secondary"
          aria-hidden="true"
        ></i>
        <h6 class="text-secondary">New tab</h6>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: "NewTabCard",
};
</script>
